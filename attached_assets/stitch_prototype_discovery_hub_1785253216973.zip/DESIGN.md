---
name: Venture Canvas
colors:
  surface: '#f9f9ff'
  surface-dim: '#d3daea'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f3ff'
  surface-container: '#e7eefe'
  surface-container-high: '#e2e8f8'
  surface-container-highest: '#dce2f3'
  on-surface: '#151c27'
  on-surface-variant: '#434653'
  inverse-surface: '#2a313d'
  inverse-on-surface: '#ebf1ff'
  outline: '#737784'
  outline-variant: '#c3c6d5'
  surface-tint: '#1d59c1'
  primary: '#003c90'
  on-primary: '#ffffff'
  primary-container: '#0f52ba'
  on-primary-container: '#bcceff'
  inverse-primary: '#b0c6ff'
  secondary: '#bb0011'
  on-secondary: '#ffffff'
  secondary-container: '#e22525'
  on-secondary-container: '#fffbff'
  tertiary: '#732900'
  on-tertiary: '#ffffff'
  tertiary-container: '#993900'
  on-tertiary-container: '#ffc0a7'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d9e2ff'
  primary-fixed-dim: '#b0c6ff'
  on-primary-fixed: '#001945'
  on-primary-fixed-variant: '#00419c'
  secondary-fixed: '#ffdad6'
  secondary-fixed-dim: '#ffb4ab'
  on-secondary-fixed: '#410002'
  on-secondary-fixed-variant: '#93000a'
  tertiary-fixed: '#ffdbcd'
  tertiary-fixed-dim: '#ffb596'
  on-tertiary-fixed: '#360f00'
  on-tertiary-fixed-variant: '#7d2d00'
  background: '#f9f9ff'
  on-background: '#151c27'
  surface-variant: '#dce2f3'
typography:
  display-lg:
    fontFamily: Hanken Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Hanken Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  headline-md-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  container-max: 1280px
  gutter: 1.5rem
  margin-mobile: 1rem
  stack-sm: 0.5rem
  stack-md: 1rem
  stack-lg: 2rem
---

## Brand & Style

This design system is built for a professional startup ecosystem where clarity, trust, and product-focused utility are paramount. The aesthetic follows a **Corporate / Modern** approach with leanings toward **Minimalism** to ensure that the user's focus remains on the "Prototype Image."

The visual language communicates reliability and institutional quality through a structured layout and high-legibility typography. It avoids unnecessary decoration, instead using subtle borders and generous whitespace to differentiate content blocks. The emotional response is one of confidence and efficiency, positioning the portal as a serious platform for entrepreneurs and investors to showcase and evaluate high-potential ideas.

## Colors

The palette is anchored by a deep **Professional Blue** (Primary), used for core branding, primary actions, and navigational cues to establish authority and trust. **Active Red** (Secondary) is reserved strictly for high-engagement "Like" states and urgent feedback, providing a sharp contrast against the blue.

Neutral greys serve as the backbone for the UI:
- **Surface Neutrals:** Off-whites and light greys for background layers and description blocks.
- **Structural Neutrals:** Mid-tone greys for borders, inactive icons (chat, save, share), and secondary metadata.
- **Text Neutrals:** Near-black for primary headlines to ensure maximum readability.

## Typography

This design system uses **Hanken Grotesk** for headlines to provide a sharp, contemporary edge that feels "startup-ready." **Inter** is utilized for body text and labels to maintain a neutral, systematic, and highly readable experience across all data-heavy sections.

Scale hierarchy is strictly enforced. Large display sizes are used for product names, while labels and metadata use smaller, semi-bold weights to create clear visual distinction without adding visual noise. Mobile sizes scale down for headlines to prevent excessive wrapping while maintaining the professional weight.

## Layout & Spacing

The system employs a **Fixed Grid** layout for the main portal to ensure consistency during product showcases. The primary interface is divided into a three-column logic inspired by the reference sketch:
1.  **Left Column (Description Block):** Contextual data and prototype details.
2.  **Center Column (Prototype Showcase):** The focal point, featuring the largest real estate for high-fidelity images/renders.
3.  **Right Column (Interactive Bar):** A slim, vertical stack for core interactions (Chat, Like, Save, Share).

Spacing follows an 8px base unit. Layouts reflow on mobile to a single-column stack: Prototype Image first, followed by the Interactive Bar (horizontal), and then the Description Block.

## Elevation & Depth

To maintain a clean and professional look, this design system uses **Low-Contrast Outlines** and **Tonal Layers** rather than heavy shadows. 

- **Surface 0:** The main application background (Light Grey).
- **Surface 1:** Feed cards and description blocks (White), defined by a 1px border in a neutral-light grey.
- **Interactive Depth:** Only the "Prototype Image" container may use a subtle, extra-diffused ambient shadow to make the product "pop" from the background. 
- **Buttons:** Use flat fills; depth is communicated through subtle color shifts (darkening) on hover rather than physical elevation.

## Shapes

The design system utilizes **Soft** geometry. A standard radius of `0.25rem` (4px) is applied to input fields and small buttons to maintain a precise, engineered feel. 

Larger containers, such as **Feed Cards** and the **Prototype Image**, use `0.5rem` (8px) to soften the overall presentation without veering into "playful" territory. Interactive icons are housed in circular or soft-square frames to ensure they are easily identifiable as touch/click targets.

## Components

### Feed Cards
The primary container for a startup entry. It features a 1px neutral border, ample internal padding (`stack-lg`), and houses the description, image, and interactive rail in a cohesive unit.

### Interactive Icons
- **Icon Style:** Linear/Outlined for inactive states; Solid/Filled for active states.
- **Chat, Save, Share:** Use Primary Blue or Neutral Grey for outlines.
- **Like:** Use the Secondary Red for the filled state. 
- Icons should be paired with a `label-sm` below them to ensure the function is clear.

### Description Blocks
Styled with a light-grey background (`Surface 0`) to distinguish them from the white card background. Use `label-md` for headers within the block and `body-md` for the "n of prototype" and details.

### Buttons
- **Primary:** Solid Primary Blue with white text.
- **Secondary:** Outlined Primary Blue with blue text.
- **States:** 10% black overlay on hover; 20% black overlay on press.

### Input Fields
Clean, rectangular fields with 1px neutral borders. On focus, the border transitions to Primary Blue with a 2px outer glow in a semi-transparent primary tint.